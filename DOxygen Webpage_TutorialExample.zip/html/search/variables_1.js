var searchData=
[
  ['b',['b',['../struct_box_struct__struct.html#a148e3876077787926724625411d6e7a9',1,'BoxStruct_struct']]]
];
