var searchData=
[
  ['boxstruct_5fstruct',['BoxStruct_struct',['../struct_box_struct__struct.html',1,'']]]
];
