var searchData=
[
  ['boxenum_5fenum',['BoxEnum_enum',['../doxygen__c_8h.html#abdf4994e8e07b3eda6c6a5a9bf5357e4',1,'doxygen_c.h']]]
];
