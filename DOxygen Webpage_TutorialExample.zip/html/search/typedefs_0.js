var searchData=
[
  ['boxenum',['BoxEnum',['../doxygen__c_8h.html#a354be0627e025b594a719a4c3f92a69f',1,'doxygen_c.h']]],
  ['boxstruct',['BoxStruct',['../doxygen__c_8h.html#a718548848862b3d5da8f7c7cea677de1',1,'doxygen_c.h']]]
];
