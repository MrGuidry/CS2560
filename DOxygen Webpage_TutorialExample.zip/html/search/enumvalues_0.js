var searchData=
[
  ['boxenum_5fetc',['BOXENUM_ETC',['../doxygen__c_8h.html#abdf4994e8e07b3eda6c6a5a9bf5357e4a227130e825c6c4506cc4a226539d85fb',1,'doxygen_c.h']]],
  ['boxenum_5ffirst',['BOXENUM_FIRST',['../doxygen__c_8h.html#abdf4994e8e07b3eda6c6a5a9bf5357e4a2bf0bdd7b9b287724c66f6c0f74ceb01',1,'doxygen_c.h']]],
  ['boxenum_5fsecond',['BOXENUM_SECOND',['../doxygen__c_8h.html#abdf4994e8e07b3eda6c6a5a9bf5357e4a3ede3b6dfb2dbdac72634f0334e11c63',1,'doxygen_c.h']]]
];
