var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "Theater.c", "_theater_8c.html", "_theater_8c" ]
];