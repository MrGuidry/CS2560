var searchData=
[
  ['columns',['COLUMNS',['../_theater_8c.html#a06c6c391fc11d106e9909f0401b255b1',1,'Theater.c']]]
];
