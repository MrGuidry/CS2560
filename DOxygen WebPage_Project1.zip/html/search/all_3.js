var searchData=
[
  ['getseatsauditorium',['getSeatsAuditorium',['../_theater_8c.html#a400fb8b4fbe42c5dd1cc5684546dcfac',1,'Theater.c']]],
  ['getseatsrow',['getSeatsRow',['../_theater_8c.html#a01ed832a98b74b1de956f1c791f5ae6f',1,'Theater.c']]],
  ['getseatssold',['getSeatsSold',['../_theater_8c.html#aeec6a398129dd70ea7b4c925fb75323e',1,'Theater.c']]]
];
