var searchData=
[
  ['buytickets',['buyTickets',['../_theater_8c.html#a639db07b05e71731666530ade6bb28aa',1,'Theater.c']]]
];
