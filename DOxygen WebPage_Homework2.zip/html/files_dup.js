var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "OceanLevels.c", "_ocean_levels_8c.html", "_ocean_levels_8c" ],
    [ "PatternDisplays.c", "_pattern_displays_8c.html", "_pattern_displays_8c" ],
    [ "RestaurantBill.c", "_restaurant_bill_8c.html", "_restaurant_bill_8c" ],
    [ "StockTransactionProgram.c", "_stock_transaction_program_8c.html", "_stock_transaction_program_8c" ]
];