var searchData=
[
  ['patterndisplays_2ec',['PatternDisplays.c',['../_pattern_displays_8c.html',1,'']]]
];
