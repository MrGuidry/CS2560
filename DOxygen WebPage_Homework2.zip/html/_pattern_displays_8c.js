var _pattern_displays_8c =
[
    [ "PatternDisplays", "_pattern_displays_8c.html#a89c463fb2eb2b57f08affb226b84940c", null ]
];